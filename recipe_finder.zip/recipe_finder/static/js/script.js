// Toggle mobile menu
document.addEventListener('DOMContentLoaded', function() {
    // Animate recipe cards on load
    const cards = document.querySelectorAll('.recipe-card');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });

    // Mark ingredients as checked when clicked
    document.querySelectorAll('.recipe-ingredients li').forEach(item => {
        item.addEventListener('click', function(e) {
            if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'LABEL') {
                const checkbox = this.querySelector('input[type="checkbox"]');
                checkbox.checked = !checkbox.checked;
            }
        });
    });

    // Print recipe functionality
    const printBtn = document.querySelector('.print-recipe');
    if (printBtn) {
        printBtn.addEventListener('click', function() {
            window.print();
        });
    }
});