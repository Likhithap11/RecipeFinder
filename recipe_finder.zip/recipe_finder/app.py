from flask import Flask, render_template, request, redirect, url_for, session, flash
import json
import os
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import timedelta

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
app.permanent_session_lifetime = timedelta(days=7)

def load_recipes():
    try:
        with open('data/recipes.json') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Error loading recipes: {e}")
        return []

# Global recipes variable
RECIPES = load_recipes()

# Sample user database (in production, use a real database)
users = {
    'admin': {
        'password': generate_password_hash('admin123'),
        'dietary_restrictions': []
    }
}

# Load recipes
with open('data/recipes.json') as f:
    recipes = json.load(f)

@app.route('/')
def index():
    return render_template('index.html', recipes=RECIPES[:3])

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in users and check_password_hash(users[username]['password'], password):
            session.permanent = True
            session['username'] = username
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in users:
            flash('Username already exists', 'danger')
        else:
            users[username] = {
                'password': generate_password_hash(password),
                'dietary_restrictions': []
            }
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html')


@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    return render_template('dashboard.html', 
                         username=session['username'],
                         recipes=RECIPES[:3])

@app.route('/find_recipes', methods=['POST'])
def find_recipes():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    ingredients = request.form.get('ingredients', '').split(',')
    ingredients = [i.strip().lower() for i in ingredients if i.strip()]
    
    matched_recipes = []
    for recipe in RECIPES:
        if any(ing in [r.lower() for r in recipe['ingredients']] for ing in ingredients):
            matched_recipes.append(recipe)
    
    return render_template('dashboard.html', 
                         username=session['username'],
                         recipes=matched_recipes,
                         search_term=', '.join(ingredients))
@app.route('/recipe/<int:recipe_id>')
def recipe_detail(recipe_id):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    recipe = next((r for r in recipes if r['id'] == recipe_id), None)
    if not recipe:
        flash('Recipe not found', 'danger')
        return redirect(url_for('dashboard'))
    
    return render_template('recipe_detail.html', recipe=recipe)

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)